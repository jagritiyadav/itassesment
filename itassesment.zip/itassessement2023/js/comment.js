function addComment() {
    const nameInput = document.getElementById("name");
    const commentInput = document.getElementById("comment");

    const name = nameInput.value;
    const comment = commentInput.value;

    if (name.trim() === "" || comment.trim() === "") {
      alert("Please enter both name and comment.");
      return;
    }

    // Create a new comment element
    const newComment = document.createElement("div");
    newComment.className = "comment";
    newComment.innerHTML = `<strong>${name}:</strong> ${comment}`;

    // Append the new comment to the comment list
    const commentList = document.getElementById("comments");
    commentList.appendChild(newComment);

    // Clear the form fields after adding the comment
    nameInput.value = "";
    commentInput.value = "";
  }