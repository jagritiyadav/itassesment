function validateForm() {
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const messageInput = document.getElementById("message");

    // Simple name validation (non-empty)
    if (nameInput.value.trim() === "") {
      alert("Please enter your name.");
      nameInput.focus();
      return false;
    }

    // Email validation using regular expression
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(emailInput.value)) {
      alert("Please enter a valid email address.");
      emailInput.focus();
      return false;
    }

    // Simple message validation (non-empty)
    if (messageInput.value.trim() === "") {
      alert("Please enter your message.");
      messageInput.focus();
      return false;
    }

    // If all validations pass, the form will be submitted
    return true;
  }